import React from 'react'
import LoginPage from './Login'
import CreateAccountPage from '../components/NewAccount'
function Account() {
  return (
    <div className='loginPage'>
     <LoginPage/>
    </div>
  )
}

export default Account